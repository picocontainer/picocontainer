public class TestComp {
	public TestComp() {
	}
}

