package org.picocontainer.web.sample.ajaxemail;

@SuppressWarnings("serial")
public class AjaxEmailException extends RuntimeException {
    public AjaxEmailException(String message) {
        super(message);
    }
}
