package org.picocontainer.persistence.hibernate;

public interface Fooable {

    Integer getId();

    String getFoo();

}
