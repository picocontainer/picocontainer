package org.picocontainer.web.struts;


public interface TestAction {

    public TestService getService();

}