package org.picocontainer.script.testmodel;

public class SomeAssemblyScope {

}
