To be able to perform a build of the picocontainer site, you must first execute:

mvn -Preporting install

on all the other PicoContainer projects.