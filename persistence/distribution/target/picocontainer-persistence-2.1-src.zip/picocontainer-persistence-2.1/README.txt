Build notes: https://svn.codehaus.org/picocontainer/java/2.x/trunk/BUILD.txt
Release notes: https://svn.codehaus.org/picocontainer/java/2.x/trunk/RELEASE.txt
