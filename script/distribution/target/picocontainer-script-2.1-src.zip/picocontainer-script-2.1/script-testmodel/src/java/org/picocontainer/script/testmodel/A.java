package org.picocontainer.script.testmodel;

/**
 * @author Mauro Talevi
 */
public class A extends X {

}
