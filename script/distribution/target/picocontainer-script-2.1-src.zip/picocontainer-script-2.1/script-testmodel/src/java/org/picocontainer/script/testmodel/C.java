package org.picocontainer.script.testmodel;

/**
 * @author Mauro Talevi
 */
public class C extends X {

}
